# Sample Python log parser script
